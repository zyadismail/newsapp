const GETBREAKINGNEWS = 'v2/top-headlines';

const GETALLNEWS = 'v2/everything';