const API_KEY = '65d60855371f462f956b9d4095ec4b0f';

final List<String> category = [
  'Technology',
  'Business',
  'Sport',
  'Health',
  'Science',
  'Entertainment',
];